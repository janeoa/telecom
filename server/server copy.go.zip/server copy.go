package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"log"
	"net"
	"os"
	"strings"

	"github.com/jacobsa/go-serial/serial"
)

type Data struct {
	Command string
	Phone   string
	Text    string
}

func main() {

	fmt.Println("connecting to UART...")
	options := serial.OpenOptions{
		PortName:        "/dev/cu.usbmodem14201",
		BaudRate:        9600,
		DataBits:        8,
		StopBits:        1,
		MinimumReadSize: 4,
	}
	port, err := serial.Open(options)
	if err != nil {
		log.Fatalf("serial.Open: %v", err)
	}

	b := []byte{0x43, 0x75, 0x6E, 0x74}
	n, err := port.Write(b)
	if err != nil {
		log.Fatalf("port.Write: %v", err)
	}

	fmt.Println("Wrote", n, "bytes.")

	fmt.Println("Launching server...")

	// listen on all interfaces
	ln, _ := net.Listen("tcp", ":8081")
	fmt.Println("is it waiting? 1")
	// accept connection on port
	conn, _ := ln.Accept()
	fmt.Println("is it waiting? 2")

	// run loop forever (or until ctrl-c)
	for {
		// will listen for message to process ending in newline (\n)
		message, err := bufio.NewReader(conn).ReadString('\n')
		// output message received

		if err == nil {
			fmt.Print("Message Received:", string(message))
			var data Data

			err := json.Unmarshal([]byte(message), &data)
			if err != nil {
				fmt.Println("Problem decoding JSON ", err)
			}
			fmt.Println(data.Command)
			if strings.Compare(data.Command, "call") == 0 {
				fmt.Println("calling... ", data.Phone)
				b := []byte{0x41, 0x54, 0x0D, 0x00} //
				n, err := port.Write(b)
				if err != nil {
					log.Fatalf("port.Write: %v", err)
				}

				fmt.Println("Wrote", n, "bytes.")
			}

			// if strings.Compare(message, "ping") != 0 {
			// 	conn.Write([]byte("pong" + "\n"))
			// }
		} else {
			// fmt.Print("err:", (err))
			fmt.Print("Connection closed\n")
			defer port.Close()
			os.Exit(0)

		}
		// sample process for string received
		//newmessage := strings.ToUpper(message)
		// send new string back to client
		// if strings.Compare(newmessage, "") != 0 {
		// 	conn.Write([]byte(newmessage + "\n"))
		// }
	}
}
