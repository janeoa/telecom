package main

import (
	"fmt"
	"io"
	"log"
	"strings"
	"time"

	"github.com/fatih/color"
	"github.com/mikepb/go-serial"
)

func main() {
	options := serial.RawOptions
	options.BitRate = 9600
	p, err := options.Open("/dev/cu.wchusbserial1420")
	if err != nil {
		log.Panic(err)
	}
	defer p.Close()

	// go recieve(p)

	// for {
	time.Sleep(2 * time.Second)
	// n, err := p.Write([]byte{0x0a})
	n, err := p.WriteString("AT\r\n")
	color.Cyan("Wrote %d bytes, err: %s", n, err)
	// }

}

func recieve(p io.ReadWriteCloser) {
	command := make([]byte, 256)
	command_index := 0

	for {
		time.Sleep(200 * time.Millisecond)
		for {
			buf := make([]byte, 1)
			if c, err := p.Read(buf); err != nil {
				fmt.Println(c)
				fmt.Println(err)
			} else {
				command[command_index] = buf[0]
				command_index = command_index + 1
				// fmt.Println(string(buf))
			}
			if buf[0] == '\n' {
				command_index = 0
				// color.Blue(hex.Dump(command))
				color.Magenta(strings.TrimSuffix(string(command), "\r\n"))
				command = make([]byte, 256)
				break
			}
		}
	}
}
